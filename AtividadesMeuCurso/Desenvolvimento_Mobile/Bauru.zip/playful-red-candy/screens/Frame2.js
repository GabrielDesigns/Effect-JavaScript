import * as React from "react";
import {
  StyleSheet,
  View,
  Text,
  Pressable,
  TouchableOpacity,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, Padding, Border, FontSize } from "../GlobalStyles";

const Frame2 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.view}>
      <View style={styles.home}>
        <View style={styles.homeIndicator} />
      </View>
      <View style={[styles.child, styles.itemLayout]} />
      <View style={[styles.item, styles.itemLayout]} />
      <View style={styles.onveniences}>
        <Text
          style={[
            styles.crescimentoEconmicoEmContainer,
            styles.umaContainerTypo,
          ]}
        >
          <Text style={styles.text}>{` `}</Text>
          <Text style={styles.crescimentoEconmicoEm}>
            Crescimento Econômico em Bauru
          </Text>
        </Text>
        <View style={styles.onveniences1}>
          <View style={styles.tagSpaceBlock}>
            <Text style={[styles.text1, styles.text1Clr]}>1930</Text>
          </View>
          <View style={[styles.tag1, styles.tagSpaceBlock]}>
            <Text style={[styles.text1, styles.text1Clr]}>1960</Text>
          </View>
          <View style={[styles.tag1, styles.tagSpaceBlock]}>
            <Text style={[styles.text1, styles.text1Clr]}>1990</Text>
          </View>
          <View style={[styles.tag1, styles.tagSpaceBlock]}>
            <Text style={[styles.text1, styles.text1Clr]}>2005</Text>
          </View>
        </View>
      </View>
      <View style={[styles.total, styles.totalLayout]}>
        <View style={[styles.totalChild, styles.totalLayout]} />
        <TouchableOpacity
          style={[styles.btn, styles.btnPosition]}
          activeOpacity={0.2}
          onPress={() => navigation.navigate("Frame")}
        >
          <Text style={styles.next}>Next</Text>
        </TouchableOpacity>
        <Text style={[styles.entre2Mil, styles.entre2MilClr]}>
          Entre 2 mil até 8 mil
        </Text>
        <Text style={[styles.custoDeVida, styles.custoDeVidaLayout]}>
          Custo de Vida
        </Text>
      </View>
      <View style={styles.cart}>
        <Image
          style={[styles.parameterIcon, styles.parameterIconPosition]}
          contentFit="cover"
          source={require("../assets/parameter1@3x.png")}// o erro esta aqui
        />
        <Text style={[styles.umaBreveHistria, styles.text1Clr]}>
          Uma breve história de Bauru
        </Text>
        <Text style={[styles.bauruUmaContainer, styles.umaContainerTypo]}>
          {`Bauru é uma cidade brasileira no estado `}de São Paulo, conhecida
          por sua rica história e desenvolvimento econômico. Fundada em 1896,
          uma região prosperou inicialmente com a chegada da ferrovia,
          impulsionan{`do o comércio e a agricultura. `}
        </Text>
        <Text style={[styles.estaoBauruNob, styles.custoDeVidaLayout]}>
          {" "}
          Estação Bauru (NOB)
        </Text>
      </View>
      <TouchableOpacity
        style={styles.back}
        activeOpacity={0.2}
        onPress={() => navigation.navigate("Frame1")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/back@3x.png")}// o erro esta aqui
        />
      </TouchableOpacity>
      <View style={styles.iphoneXOrNewer}>
        <Image
          style={styles.notchIcon}
          contentFit="cover"
          source={require("../assets/notch@3x.png")}// o erro esta aqui
        />
        <Image
          style={styles.rightSideIcon}
          contentFit="cover"
          source={require("../assets/left-side1@3x.png")}// o erro esta aqui
        />
        <Image
          style={[styles.leftSideIcon, styles.btnPosition]}
          contentFit="cover"
          source={require("../assets/left-side1@3x.png")}// o erro esta aqui
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  itemLayout: {
    height: 1,
    backgroundColor: Color.colorDarkgray_200,
    width: 327,
    left: 24,
    position: "absolute",
  },
  umaContainerTypo: {
    fontFamily: FontFamily.manropeBold,
    fontWeight: "700",
  },
  text1Clr: {
    color: Color.dark,
    textAlign: "left",
  },
  tagSpaceBlock: {
    paddingVertical: Padding.p_7xs,
    paddingHorizontal: Padding.p_5xs,
    borderRadius: Border.br_6xs,
    backgroundColor: Color.colorWhite,
    flexDirection: "row",
  },
  totalLayout: {
    height: 72,
    width: 327,
    position: "absolute",
  },
  btnPosition: {
    top: 12,
    position: "absolute",
  },
  entre2MilClr: {
    color: Color.colorBlack,
    left: 16,
  },
  custoDeVidaLayout: {
    lineHeight: 20,
    textAlign: "left",
    position: "absolute",
  },
  parameterIconPosition: {
    top: 0,
    left: 0,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -66.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorDarkslategray_100,
    width: 134,
    height: 5,
    position: "absolute",
  },
  home: {
    top: 782,
    width: 375,
    height: 30,
    left: 0,
    position: "absolute",
  },
  child: {
    top: 434,
  },
  item: {
    top: 591,
  },
  text: {
    fontSize: FontSize.size_lg,
  },
  crescimentoEconmicoEm: {
    fontSize: FontSize.size_base,
  },
  crescimentoEconmicoEmContainer: {
    color: "rgba(70, 70, 70, 0.8)",
    textAlign: "left",
    lineHeight: 24,
    top: 0,
    left: 0,
    position: "absolute",
  },
  text1: {
    fontFamily: FontFamily.manropeMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
  },
  tag1: {
    marginLeft: 8,
  },
  onveniences1: {
    top: 36,
    flexDirection: "row",
    left: 0,
    position: "absolute",
  },
  onveniences: {
    top: 604,
    width: 269,
    height: 67,
    left: 24,
    position: "absolute",
  },
  totalChild: {
    borderRadius: Border.br_xl,
    shadowColor: "rgba(0, 0, 0, 0.01)",
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    backgroundColor: Color.colorWhite,
    height: 72,
    top: 0,
    left: 0,
  },
  next: {
    fontWeight: "600",
    fontFamily: FontFamily.manropeSemiBold,
    color: Color.colorWhite,
    fontSize: FontSize.size_base,
    textAlign: "left",
    lineHeight: 24,
  },
  btn: {
    left: 178,
    borderRadius: Border.br_xs,
    backgroundColor: Color.primary,
    alignItems: "flex-end",
    justifyContent: "flex-end",
    paddingHorizontal: 20,
    paddingVertical: 12,
    flexDirection: "row",
  },
  entre2Mil: {
    top: 40,
    fontSize: 10,
    lineHeight: 12,
    fontFamily: FontFamily.manropeMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  custoDeVida: {
    top: 18,
    color: Color.colorBlack,
    left: 16,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.manropeBold,
    fontWeight: "700",
  },
  total: {
    top: 710,
    left: 24,
  },
  parameterIcon: {
    height: 218,
    width: 327,
  },
  umaBreveHistria: {
    top: 233,
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.manropeBold,
    fontWeight: "700",
    lineHeight: 24,
    left: 0,
    position: "absolute",
  },
  bauruUmaContainer: {
    top: 313,
    left: 3,
    fontSize: 15,
    color: Color.colorGray,
    textAlign: "left",
    lineHeight: 24,
    position: "absolute",
  },
  estaoBauruNob: {
    top: 261,
    color: Color.colorDarkgray_100,
    fontFamily: FontFamily.manropeMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    left: 0,
  },
  cart: {
    top: 103,
    height: 457,
    width: 327,
    left: 24,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  back: {
    top: 52,
    width: 32,
    height: 32,
    left: 24,
    position: "absolute",
  },
  notchIcon: {
    top: -2,
    right: 86,
    bottom: 16,
    left: 86,
    maxWidth: "100%",
    maxHeight: "100%",
    display: "none",
    position: "absolute",
    overflow: "hidden",
  },
  rightSideIcon: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    left: 21,
    width: 54,
    height: 21,
  },
  iphoneXOrNewer: {
    height: "5.41%",
    top: "0%",
    right: "0%",
    bottom: "94.59%",
    left: "0%",
    position: "absolute",
    overflow: "hidden",
    width: "100%",
  },
  view: {
    borderRadius: 26,
    backgroundColor: Color.colorWhitesmoke,
    flex: 1,
    height: 811,
    overflow: "hidden",
    width: "100%",
  },
});

export default Frame2;
