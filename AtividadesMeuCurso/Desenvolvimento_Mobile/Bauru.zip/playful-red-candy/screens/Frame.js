import * as React from "react";
import {
  StyleSheet,
  View,
  Pressable,
  Text,
  TouchableOpacity,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const Frame = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.view, styles.viewLayout]}>
      <View style={styles.home}>
        <View style={styles.homeIndicator} />
      </View>
      <View style={[styles.iphoneXOrNewer, styles.viewLayout]}>
        <Image
          style={styles.notchIcon}
          contentFit="cover"
          source={require("../assets/notch@3x.png")}// o erro esta aqui
        />
        <Image
          style={styles.rightSideIcon}
          contentFit="cover"
          source={require("../assets/right-side1@3x.png")}// o erro esta aqui
        />
        <Image
          style={[styles.leftSideIcon, styles.cartPosition]}
          contentFit="cover"
          source={require("../assets/left-side1@3x.png")}// o erro esta aqui
        />
      </View>
      <View style={[styles.cart, styles.cartPosition]}>
        <Image
          style={styles.parameterIcon}
          contentFit="cover"
          source={require("../assets/parameter1@3x.png")}// o erro esta aqui
        />
        <Text style={[styles.fundadoresDaCidade, styles.textFlexBox]}>
          Fundadores da Cidade de bauru
        </Text>
        <Text style={[styles.bauruFundadaEmContainer, styles.textFlexBox]}>
          {`Bauru, fundada em 1896, tem sua história `}entrelaçada com nomes
          como Salgado Filho{`, Antônio Alves e Jesuíno José Soares. Esses `}
          visionários contribuíram para o desenvolvimento
          {` inicial da cidade, marcando o início de uma jornada `}que moldaria
          o futuro de Bauru.
        </Text>
        <Text style={[styles.text, styles.textFlexBox]}>{` `}</Text>
      </View>
      <TouchableOpacity
        style={[styles.tabBar, styles.tabLayout]}
        activeOpacity={0.2}
        onPress={() => navigation.navigate("Frame2")}
      >
        <View style={[styles.tabBarChild, styles.tabLayout]} />
        <Text style={[styles.return, styles.textFlexBox]}>Return</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  viewLayout: {
    width: "100%",
    overflow: "hidden",
  },
  cartPosition: {
    left: 21,
    position: "absolute",
  },
  textFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  tabLayout: {
    height: 41,
    width: 196,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -66.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorDarkslategray_100,
    width: 134,
    height: 5,
    position: "absolute",
  },
  home: {
    top: 782,
    width: 375,
    height: 30,
    left: 0,
    position: "absolute",
  },
  notchIcon: {
    top: -2,
    right: 82,
    bottom: 15,
    left: 82,
    maxWidth: "100%",
    maxHeight: "100%",
    display: "none",
    position: "absolute",
    overflow: "hidden",
  },
  rightSideIcon: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    top: 12,
    width: 54,
    height: 21,
  },
  iphoneXOrNewer: {
    height: "5.42%",
    top: "0%",
    right: "0%",
    bottom: "94.58%",
    left: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  parameterIcon: {
    width: 327,
    height: 218,
    left: 3,
    top: 0,
    position: "absolute",
  },
  fundadoresDaCidade: {
    top: 233,
    fontSize: FontSize.size_lg,
    color: Color.dark,
    fontFamily: FontFamily.manropeBold,
    fontWeight: "700",
    textAlign: "left",
    lineHeight: 24,
    left: 3,
  },
  bauruFundadaEmContainer: {
    top: 335,
    fontSize: 13,
    color: Color.colorGray,
    fontFamily: FontFamily.manropeBold,
    fontWeight: "700",
    textAlign: "left",
    lineHeight: 24,
    left: 0,
  },
  text: {
    top: 261,
    fontSize: FontSize.size_sm,
    lineHeight: 20,
    fontWeight: "500",
    fontFamily: FontFamily.manropeMedium,
    color: Color.colorDarkgray_100,
    left: 3,
  },
  cart: {
    top: 103,
    width: 330,
    height: 479,
  },
  tabBarChild: {
    borderRadius: Border.br_xl,
    backgroundColor: Color.primary,
    shadowColor: "rgba(166, 229, 255, 0.2)",
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowRadius: 20,
    elevation: 20,
    shadowOpacity: 1,
    top: 0,
    left: 0,
  },
  return: {
    top: 9,
    left: 58,
    fontSize: 24,
    lineHeight: 22,
    color: Color.colorWhite,
    fontFamily: FontFamily.manropeBold,
    fontWeight: "700",
    textAlign: "left",
  },
  tabBar: {
    top: 723,
    left: 84,
  },
  view: {
    borderRadius: Border.br_5xl,
    backgroundColor: Color.colorWhitesmoke,
    flex: 1,
    height: 784,
    overflow: "hidden",
  },
});

export default Frame;
