import * as React from "react";
import {
  ImageBackground,
  StyleSheet,
  View,
  Pressable,
  Text,
  TouchableOpacity,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const Frame1 = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.view, styles.viewLayout]}>
      <ImageBackground
        style={[styles.pexelsMichaelBlock32255313Icon, styles.homePosition]}
        resizeMode="cover"
        source={require("../assets/pexelsmichaelblock32255313@3x.png")}// o erro esta aqui
      />
      <View style={[styles.rectangle, styles.rectangleBg]} />
      <TouchableOpacity
        style={[styles.btnWrapper, styles.btnLayout]}
        activeOpacity={0.2}
        onPress={() => navigation.navigate("Frame2")}
      >
        <View style={[styles.btn, styles.btnLayout]}>
          <View style={[styles.btnChild, styles.btnLayout]} />
          <Text style={[styles.entrar, styles.entrarTypo]}> Entrar</Text>
        </View>
      </TouchableOpacity>
      <Text style={[styles.bemVindoA, styles.bemVindoAPosition]}>
        Bem Vindo a Bauru
      </Text>
      <Text style={[styles.prepareSeParaUma, styles.bemVindoAPosition]}>
        Prepare-se para uma jornada única enquanto exploramos as facetas
        fascinantes de Bauru.
      </Text>
      <View style={[styles.statusbar, styles.homePosition]}>
        <View style={[styles.iphoneXOrNewer, styles.viewLayout]}>
          <Image
            style={styles.notchIcon}
            contentFit="cover"
            source={require("../assets/notch@3x.png")}// o erro esta aqui
          />
          <Image
            style={styles.rightSideIcon}
            contentFit="cover"
            source={require("../assets/right-side@3x.png")}// o erro esta aqui
          />
          <Image
            style={[styles.leftSideIcon, styles.entrarPosition]}
            contentFit="cover"
            source={require("../assets/left-side@3x.png")}// o erro esta aqui
          />
        </View>
      </View>
      <View style={[styles.home, styles.homePosition]}>
        <View style={[styles.homeIndicator, styles.rectangleBg]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  viewLayout: {
    width: "100%",
    overflow: "hidden",
  },
  homePosition: {
    width: 375,
    left: 0,
    position: "absolute",
  },
  rectangleBg: {
    backgroundColor: Color.colorWhite,
    position: "absolute",
  },
  btnLayout: {
    height: 48,
    width: 165,
    position: "absolute",
  },
  entrarTypo: {
    fontFamily: FontFamily.manropeSemiBold,
    fontWeight: "600",
  },
  bemVindoAPosition: {
    width: 279,
    textAlign: "center",
    color: Color.dark,
    left: 48,
    position: "absolute",
  },
  entrarPosition: {
    top: 12,
    position: "absolute",
  },
  pexelsMichaelBlock32255313Icon: {
    top: 0,
    width: 375,
    height: 812,
  },
  rectangle: {
    top: 471,
    left: 24,
    width: 327,
    height: 311,
    borderRadius: Border.br_5xl,
  },
  btnChild: {
    borderRadius: Border.br_xs,
    backgroundColor: Color.primary,
    left: 0,
    width: 165,
    top: 0,
  },
  entrar: {
    left: 38,
    fontSize: FontSize.size_base,
    lineHeight: 24,
    color: Color.colorWhite,
    textAlign: "left",
    top: 12,
    position: "absolute",
  },
  btn: {
    left: 0,
    width: 165,
    top: 0,
  },
  btnWrapper: {
    top: 686,
    left: 105,
  },
  bemVindoA: {
    top: 519,
    fontSize: 26,
    lineHeight: 36,
    fontWeight: "800",
    fontFamily: FontFamily.manropeExtraBold,
    height: 72,
  },
  prepareSeParaUma: {
    top: 603,
    fontSize: FontSize.size_sm,
    height: 55,
    opacity: 0.5,
    fontFamily: FontFamily.manropeSemiBold,
    fontWeight: "600",
  },
  notchIcon: {
    top: -2,
    right: 78,
    bottom: 16,
    left: 78,
    maxWidth: "100%",
    maxHeight: "100%",
    display: "none",
    position: "absolute",
    overflow: "hidden",
  },
  rightSideIcon: {
    top: 17,
    right: 15,
    width: 67,
    height: 11,
    position: "absolute",
  },
  leftSideIcon: {
    left: 21,
    width: 54,
    height: 21,
  },
  iphoneXOrNewer: {
    height: "100%",
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  statusbar: {
    height: 44,
    top: 0,
    width: 375,
  },
  homeIndicator: {
    marginLeft: -66.5,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    width: 134,
    height: 5,
  },
  home: {
    top: 782,
    height: 30,
  },
  view: {
    backgroundColor: "#e4e4e4",
    flex: 1,
    overflow: "hidden",
    height: 812,
    borderRadius: Border.br_5xl,
  },
});

export default Frame1;
