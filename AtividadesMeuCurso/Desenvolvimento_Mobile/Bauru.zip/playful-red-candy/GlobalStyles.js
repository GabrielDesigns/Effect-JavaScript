/* fonts */
export const FontFamily = {
  manropeSemiBold: "Manrope-SemiBold",
  manropeExtraBold: "Manrope-ExtraBold",
  manropeBold: "Manrope-Bold",
  manropeMedium: "Manrope-Medium",
};
/* font sizes */
export const FontSize = {
  size_sm: 14,
  size_base: 16,
  size_lg: 18,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  dark: "#464646",
  colorDarkslategray_100: "#313131",
  primary: "#4c9fc1",
  colorWhitesmoke: "#f9f9fb",
  colorDarkgray_100: "#a1a7b0",
  colorDarkgray_200: "rgba(161, 167, 176, 0.15)",
  colorGray: "rgba(0, 0, 0, 0.54)",
  colorBlack: "#000",
};
/* Paddings */
export const Padding = {
  p_5xs: 8,
  p_7xs: 6,
};
/* border radiuses */
export const Border = {
  br_5xl: 24,
  br_81xl: 100,
  br_xs: 12,
  br_xl: 20,
  br_6xs: 7,
};
