import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";

import {
  useFonts,
  Manrope_400Regular,
  Manrope_500Medium,
  Manrope_600SemiBold,
  Manrope_700Bold,
  Manrope_800ExtraBold  
} from '@expo-google-fonts/manrope';

import { createNativeStackNavigator } from "@react-navigation/native-stack";

import Frame1 from "./screens/Frame1";
import Frame from "./screens/Frame";
import Frame2 from "./screens/Frame2";

const Stack = createNativeStackNavigator();

const App = () => {

  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);  

  const [fontsLoaded] = useFonts({
    Manrope_400Regular,
    Manrope_500Medium,
    Manrope_600SemiBold,  
    Manrope_700Bold,
    Manrope_800ExtraBold     
  });

  if(!fontsLoaded) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{headerShown: false}}>
            <Stack.Screen name="Frame1" component={Frame1} />
            <Stack.Screen name="Frame" component={Frame} /> 
            <Stack.Screen name="Frame2" component={Frame2} />
          </Stack.Navigator>
        ) : null }
      </NavigationContainer>
    </>
  );
};

export default App;