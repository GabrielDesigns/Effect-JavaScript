<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["acao"])) {
        $acao = $_POST["acao"];
        
        $url = "localhost";
        $user = "root";
        $pass = "";
        $db = "testeaula";

        $conexao = mysqli_connect($url, $user, $pass, $db);

        if ($acao == "cadastrar") {
            if (isset($_POST["usuario"]) && isset($_POST["senha"])) {
                $stmt = $conexao->prepare("INSERT INTO usuarios(usuario, senha) VALUES(?, ?)");
                $stmt->bind_param("ss", $_POST["usuario"], $_POST["senha"]);

                if ($stmt->execute()) {
                    mysqli_close($conexao);
                    header('location: cadastrar.php?msg=Cadastrado com sucesso!');
                } else {
                    echo "Erro ao cadastrar Usuário " . $stmt->error;
                    mysqli_close($conexao);
                }
            }
        } elseif ($acao == "buscar") {
            if (isset($_POST["busca"])) {
                $sql = "SELECT * FROM usuarios WHERE usuario LIKE '%" . $_POST["busca"] . "%' OR senha LIKE '%" . $_POST["busca"] . "%'";
                $resultados = mysqli_query($conexao, $sql);
                
                if (mysqli_num_rows($resultados) > 0) {
                    while ($linhas = mysqli_fetch_assoc($resultados)) {
                        echo "id: " . $linhas["Id"]. " Usuário: " . $linhas["usuario"]. " Senha: " . $linhas["senha"]. "<br>";
                    }
                } else {
                    echo "Nenhum resultado encontrado";
                }
            }
        } elseif ($acao == "editar") {
            if (isset($_POST["id"], $_POST["usuario"], $_POST["senha"])) {
                $id = $_POST["id"];
                $usuario = $_POST["usuario"];
                $senha = $_POST["senha"];
                
                $stmt = $conexao->prepare("UPDATE usuarios SET usuario = ?, senha = ? WHERE Id = ?");
                $stmt->bind_param("ssi", $usuario, $senha, $id);
                
                if ($stmt->execute()) {
                    mysqli_close($conexao);
                    header('location: cadastrar.php?msg=Editado com sucesso!');
                } else {
                    echo "Erro ao editar Usuário " . $stmt->error;
                    mysqli_close($conexao);
                }
            }
        } elseif ($acao == "excluir") {
            if (isset($_POST["id"])) {
                $id = $_POST["id"];
                
                $stmt = $conexao->prepare("DELETE FROM usuarios WHERE Id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    mysqli_close($conexao);
                    header('location: cadastrar.php?msg=Excluído com sucesso!');
                } else {
                    echo "Erro ao excluir Usuário " . $stmt->error;
                    mysqli_close($conexao);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="login">

<div class="w3-display-middle w3-xlarge">
    <form action="cadastrar.php" method="post">
        Usuário: <input type="text" name="usuario"><br><br>
        Senha: <input type="password" name="senha"><br><br>
        <input type="hidden" name="acao" value="cadastrar">
        <input type="submit" value="Cadastrar" class="w3-button w3-green">
    </form>

    <form action="cadastrar.php" method="post">
        Buscar Usuário: <input type="text" name="busca">
        <input type="hidden" name="acao" value="buscar">
        <input type="submit" value="Buscar">
    </form>

    <form action="cadastrar.php" method="post">
        <input type="hidden" name="id">
        Usuário: <input type="text" name="usuario">
        Senha: <input type="password" name "senha">
        <input type="hidden" name="acao" value="editar">
        <input type="submit" value="Editar">
    </form>

    <form action="cadastrar.php" method="post">
        <input type="hidden" name="id">
        <input type="hidden" name="acao" value="excluir">
        <input type="submit" value="Excluir">
    </form>

    <!-- Caixa de texto para exibir mensagens -->
    <input type="text" name="mensagem" id="mensagem" readonly>

    <!-- Exibição de mensagens de sucesso ou erro -->
    <?php
    if (isset($_GET['msg']) && !empty($_GET['msg'])) {
        echo '<div class="w3-panel w3-pale-green w3-small">';
        echo $_GET['msg'];
        echo '</div>';
        // Preenche a caixa de texto com a mensagem
        echo '<script>document.getElementById("mensagem").value = "' . $_GET['msg'] . '";</script>';
    }
    ?>
</div>
</div>
</body>
</html>
