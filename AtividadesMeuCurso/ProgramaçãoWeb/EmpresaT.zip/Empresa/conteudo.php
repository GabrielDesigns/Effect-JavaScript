<?php
session_start();
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "Empresa";
 
$conn = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}
 
$de_id = isset($_SESSION["usuario_id"]) ? $_SESSION["usuario_id"] : 0;
 
// Verifique se a tabela 'recados' existe, se não existir, crie-a
$conn->query("CREATE TABLE IF NOT EXISTS recados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    de_id INT,
    para_id INT,
    recado TEXT,
    FOREIGN KEY (de_id) REFERENCES usuarios(id),
    FOREIGN KEY (para_id) REFERENCES usuarios(id)
)");
 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $para_email = $_POST["para_email"];
    $recado = $_POST["recado"];
 
    // Obter o id do usuário 'para' com base no email fornecido
    $stmtParaId = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmtParaId->bind_param("s", $para_email);
    $stmtParaId->execute();
    $resultParaId = $stmtParaId->get_result();
 
    if ($resultParaId && $resultParaId->num_rows > 0) {
        $rowParaId = $resultParaId->fetch_assoc();
        $para_id = $rowParaId["id"];
 
        // Agora podemos usar $para_id para inserir o recado
        $stmtInsertRecado = $conn->prepare("INSERT INTO recados (de_id, para_id, recado) VALUES (?, ?, ?)");
        $stmtInsertRecado->bind_param("iis", $de_id, $para_id, $recado);
 
        if ($stmtInsertRecado->execute()) {
            echo "Recado enviado com sucesso!";
        } else {
            echo "Erro ao enviar o recado: " . $stmtInsertRecado->error;
        }
 
        $stmtInsertRecado->close();
    } else {
        echo "Usuário 'para' não encontrado.";
    }
 
    $stmtParaId->close();
}
 
// Lista de recados
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conteúdo</title>
</head>
<body>
<div class="Cena">
    <h1>Enviar Recado</h1>
    <form action="" method="POST">
        <label>Para:</label>
        <input type="text" name="para_email" required><br>
        <label>Recado:</label>
        <textarea name="recado" rows="4" required></textarea><br>
        <button type="submit">Enviar</button>
    </form>
 
    <!-- Lista de recados -->
    <h2>Meus Recados</h2>
 
    <?php
    $sqlRecados = "SELECT recados.recado FROM recados
INNER JOIN usuarios ON recados.para_id = usuarios.id
                   WHERE recados.de_id = $de_id";
 
    $resultRecados = $conn->query($sqlRecados);
 
    if ($resultRecados) {
        if ($resultRecados->num_rows > 0) {
            while ($rowRecado = $resultRecados->fetch_assoc()) {
                echo "<p>{$rowRecado['recado']}</p>";
            }
        } else {
            echo "<p>Nenhum recado encontrado.</p>";
        }
    } else {
        echo "Erro ao buscar recados: " . $conn->error;
    }
 
    $conn->close();
    ?>
 
    <br>
    <a href="perfil.php">Meu Perfil</a> | <a href="logout.php">Sair</a>
    </div>
</body>
</html>