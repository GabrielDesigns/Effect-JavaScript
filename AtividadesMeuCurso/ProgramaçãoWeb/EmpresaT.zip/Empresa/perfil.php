<?php
session_start();

if (!isset($_SESSION["usuario_id"])) {
    header("Location: index.php");
    exit();
}

$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "Empresa"; // Lembre-se de substituir pelo nome do seu banco de dados

$conn = new mysqli($host, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

$usuario_id = $_SESSION["usuario_id"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = password_hash($_POST["senha"], PASSWORD_DEFAULT);

    $sql = "UPDATE usuarios SET nome='$nome', email='$email', senha='$senha' WHERE id=$usuario_id";

    if ($conn->query($sql) === TRUE) {
        echo "Perfil atualizado!";
    } else {
        echo "Erro ao atualizar o perfil: " . $conn->error;
    }
}

$sqlUsuario = "SELECT * FROM usuarios WHERE id=$usuario_id";
$resultUsuario = $conn->query($sqlUsuario);
$rowUsuario = $resultUsuario->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil</title>
</head>
<body>
<div class="Cena">
    <h1>Meu Perfil</h1>
    
    <form action="" method="POST">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" value="<?php echo $rowUsuario['nome']; ?>" required><br>

        <label for="email">Email:</label>
        <input type="text" name="email" value="<?php echo $rowUsuario['email']; ?>" required><br>

        <label for="senha">Nova Senha:</label>
        <input type="password" name="senha"><br>

        <button type="submit">Atualizar Perfil</button>
    </form>

    <p><a href="conteudo.php">Voltar para o Conteúdo</a></p>
    <p><a href="logout.php">Sair</a></p>
    </div>
</body>
</html>
