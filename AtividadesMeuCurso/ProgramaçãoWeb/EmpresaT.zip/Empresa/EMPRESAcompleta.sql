
CREATE DATABASE IF NOT EXISTS Empresa;
 


USE Empresa;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    senha VARCHAR(255) NOT NULL
);

create table recados(
id int primary key AUTO_INCREMENT, 
de_id int, 
para_id int,
recado varchar(300),
FOREIGN KEY (de_id) REFERENCES usuarios(id),
FOREIGN KEY (para_id) REFERENCES usuarios(id)
);

